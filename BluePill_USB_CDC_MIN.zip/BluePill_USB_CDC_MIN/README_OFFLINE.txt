BluePill STM32F103C8T6 USB CDC — minimal standalone IAR project

CubeMX is NOT required to build this archive.
Open: EWARM/Project.eww
Then: Project -> Rebuild All

Kept:
- application sources;
- USB CDC sources and descriptors;
- required HAL sources and headers;
- CMSIS headers for STM32F103xB;
- IAR project/workspace/debug settings;
- startup file and Flash linker file.

Removed:
- .ioc and .mxproject (CubeMX metadata);
- CMSIS DSP/tests/templates and headers for other STM32F1 variants;
- unused HAL source files;
- USB middleware templates;
- IAR build output, BrowseInfo, map/out/hex cache, backups and temporary settings.

The application code itself was not changed.
