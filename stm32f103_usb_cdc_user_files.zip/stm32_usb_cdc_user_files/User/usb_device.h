#ifndef __USB_DEVICE_H
#define __USB_DEVICE_H

#include "usbd_core.h"

extern USBD_HandleTypeDef hUsbDeviceFS;

void USB_Device_Init(void);

#endif
