#include "usb_device.h"
#include "usbd_desc.h"
#include "usbd_cdc.h"
#include "usbd_cdc_if.h"

USBD_HandleTypeDef hUsbDeviceFS;

void USB_Device_Init(void)
{
    if (USBD_Init(&hUsbDeviceFS, &FS_Desc, 0U) != USBD_OK)
    {
        while (1) {}
    }

    if (USBD_RegisterClass(&hUsbDeviceFS, &USBD_CDC) != USBD_OK)
    {
        while (1) {}
    }

    if (USBD_CDC_RegisterInterface(&hUsbDeviceFS,
                                   &USBD_Interface_fops_FS) != USBD_OK)
    {
        while (1) {}
    }

    if (USBD_Start(&hUsbDeviceFS) != USBD_OK)
    {
        while (1) {}
    }
}
