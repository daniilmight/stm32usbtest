#include "stm32f1xx_hal.h"
#include "usbd_core.h"
#include "usbd_cdc.h"

PCD_HandleTypeDef hpcd_USB_FS;

static void USB_PCD_MspInit(PCD_HandleTypeDef *hpcd);
static void USB_PCD_MspDeInit(PCD_HandleTypeDef *hpcd);
static void USB_PCD_ResetCallback(PCD_HandleTypeDef *hpcd);
static void USB_PCD_SetupCallback(PCD_HandleTypeDef *hpcd);
static void USB_PCD_DataOutCallback(PCD_HandleTypeDef *hpcd, uint8_t epnum);
static void USB_PCD_DataInCallback(PCD_HandleTypeDef *hpcd, uint8_t epnum);

static void USB_PCD_MspInit(PCD_HandleTypeDef *hpcd)
{
    if (hpcd->Instance == USB)
    {
        __HAL_RCC_USB_CLK_ENABLE();
        HAL_NVIC_SetPriority(USB_LP_CAN1_RX0_IRQn, 1, 0);
    }
}

static void USB_PCD_MspDeInit(PCD_HandleTypeDef *hpcd)
{
    if (hpcd->Instance == USB)
    {
        HAL_NVIC_DisableIRQ(USB_LP_CAN1_RX0_IRQn);
        __HAL_RCC_USB_CLK_DISABLE();
    }
}

USBD_StatusTypeDef USBD_LL_Init(USBD_HandleTypeDef *pdev)
{
    hpcd_USB_FS.Instance = USB;
    hpcd_USB_FS.Init.dev_endpoints = 8U;
    hpcd_USB_FS.Init.speed = PCD_SPEED_FULL;
    hpcd_USB_FS.Init.ep0_mps = PCD_EP0MPS_64;
    hpcd_USB_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
    hpcd_USB_FS.Init.low_power_enable = DISABLE;

    hpcd_USB_FS.pData = pdev;
    pdev->pData = &hpcd_USB_FS;

    if (HAL_PCD_RegisterCallback(&hpcd_USB_FS,
                                 HAL_PCD_MSPINIT_CB_ID,
                                 USB_PCD_MspInit) != HAL_OK)
    {
        return USBD_FAIL;
    }

    if (HAL_PCD_RegisterCallback(&hpcd_USB_FS,
                                 HAL_PCD_MSPDEINIT_CB_ID,
                                 USB_PCD_MspDeInit) != HAL_OK)
    {
        return USBD_FAIL;
    }

    if (HAL_PCD_Init(&hpcd_USB_FS) != HAL_OK)
    {
        return USBD_FAIL;
    }

    if (HAL_PCD_RegisterCallback(&hpcd_USB_FS,
                                 HAL_PCD_RESET_CB_ID,
                                 USB_PCD_ResetCallback) != HAL_OK)
    {
        return USBD_FAIL;
    }

    if (HAL_PCD_RegisterCallback(&hpcd_USB_FS,
                                 HAL_PCD_SETUPSTAGE_CB_ID,
                                 USB_PCD_SetupCallback) != HAL_OK)
    {
        return USBD_FAIL;
    }

    if (HAL_PCD_RegisterDataOutStageCallback(&hpcd_USB_FS,
                                             USB_PCD_DataOutCallback) != HAL_OK)
    {
        return USBD_FAIL;
    }

    if (HAL_PCD_RegisterDataInStageCallback(&hpcd_USB_FS,
                                            USB_PCD_DataInCallback) != HAL_OK)
    {
        return USBD_FAIL;
    }

    if (HAL_PCDEx_PMAConfig(&hpcd_USB_FS, 0x00U, PCD_SNG_BUF, 0x18U) != HAL_OK)
    {
        return USBD_FAIL;
    }

    if (HAL_PCDEx_PMAConfig(&hpcd_USB_FS, 0x80U, PCD_SNG_BUF, 0x58U) != HAL_OK)
    {
        return USBD_FAIL;
    }

    if (HAL_PCDEx_PMAConfig(&hpcd_USB_FS, CDC_IN_EP, PCD_SNG_BUF, 0xC0U) != HAL_OK)
    {
        return USBD_FAIL;
    }

    if (HAL_PCDEx_PMAConfig(&hpcd_USB_FS, CDC_CMD_EP, PCD_SNG_BUF, 0x100U) != HAL_OK)
    {
        return USBD_FAIL;
    }

    if (HAL_PCDEx_PMAConfig(&hpcd_USB_FS, CDC_OUT_EP, PCD_SNG_BUF, 0x110U) != HAL_OK)
    {
        return USBD_FAIL;
    }

    return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_DeInit(USBD_HandleTypeDef *pdev)
{
    HAL_NVIC_DisableIRQ(USB_LP_CAN1_RX0_IRQn);

    if (HAL_PCD_DeInit((PCD_HandleTypeDef *)pdev->pData) != HAL_OK)
    {
        return USBD_FAIL;
    }

    return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_Start(USBD_HandleTypeDef *pdev)
{
    PCD_HandleTypeDef *hpcd = (PCD_HandleTypeDef *)pdev->pData;

    HAL_NVIC_DisableIRQ(USB_LP_CAN1_RX0_IRQn);

    if (HAL_PCD_Start(hpcd) != HAL_OK)
    {
        return USBD_FAIL;
    }

#ifdef USB_CNTR_SOFM
    USB->CNTR &= (uint16_t)~(USB_CNTR_SOFM | USB_CNTR_ESOFM);
#endif

#ifdef USB_ISTR_SOF
    __HAL_PCD_CLEAR_FLAG(hpcd, USB_ISTR_SOF | USB_ISTR_ESOF);
#endif

    HAL_NVIC_ClearPendingIRQ(USB_LP_CAN1_RX0_IRQn);
    HAL_NVIC_EnableIRQ(USB_LP_CAN1_RX0_IRQn);

    return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_Stop(USBD_HandleTypeDef *pdev)
{
    HAL_NVIC_DisableIRQ(USB_LP_CAN1_RX0_IRQn);

    if (HAL_PCD_Stop((PCD_HandleTypeDef *)pdev->pData) != HAL_OK)
    {
        return USBD_FAIL;
    }

    return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_OpenEP(USBD_HandleTypeDef *pdev,
                                 uint8_t ep_addr,
                                 uint8_t ep_type,
                                 uint16_t ep_mps)
{
    if (HAL_PCD_EP_Open((PCD_HandleTypeDef *)pdev->pData,
                        ep_addr,
                        ep_mps,
                        ep_type) != HAL_OK)
    {
        return USBD_FAIL;
    }

    return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_CloseEP(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
    if (HAL_PCD_EP_Close((PCD_HandleTypeDef *)pdev->pData, ep_addr) != HAL_OK)
    {
        return USBD_FAIL;
    }

    return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_FlushEP(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
    if (HAL_PCD_EP_Flush((PCD_HandleTypeDef *)pdev->pData, ep_addr) != HAL_OK)
    {
        return USBD_FAIL;
    }

    return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_StallEP(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
    if (HAL_PCD_EP_SetStall((PCD_HandleTypeDef *)pdev->pData, ep_addr) != HAL_OK)
    {
        return USBD_FAIL;
    }

    return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_ClearStallEP(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
    if (HAL_PCD_EP_ClrStall((PCD_HandleTypeDef *)pdev->pData, ep_addr) != HAL_OK)
    {
        return USBD_FAIL;
    }

    return USBD_OK;
}

uint8_t USBD_LL_IsStallEP(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
    PCD_HandleTypeDef *hpcd = (PCD_HandleTypeDef *)pdev->pData;

    if ((ep_addr & 0x80U) == 0x80U)
    {
        return hpcd->IN_ep[ep_addr & 0x7FU].is_stall;
    }

    return hpcd->OUT_ep[ep_addr & 0x7FU].is_stall;
}

USBD_StatusTypeDef USBD_LL_SetUSBAddress(USBD_HandleTypeDef *pdev, uint8_t dev_addr)
{
    if (HAL_PCD_SetAddress((PCD_HandleTypeDef *)pdev->pData, dev_addr) != HAL_OK)
    {
        return USBD_FAIL;
    }

    return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_Transmit(USBD_HandleTypeDef *pdev,
                                   uint8_t ep_addr,
                                   uint8_t *pbuf,
                                   uint32_t size)
{
    if (HAL_PCD_EP_Transmit((PCD_HandleTypeDef *)pdev->pData,
                            ep_addr,
                            pbuf,
                            size) != HAL_OK)
    {
        return USBD_FAIL;
    }

    return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_PrepareReceive(USBD_HandleTypeDef *pdev,
                                         uint8_t ep_addr,
                                         uint8_t *pbuf,
                                         uint32_t size)
{
    if (HAL_PCD_EP_Receive((PCD_HandleTypeDef *)pdev->pData,
                           ep_addr,
                           pbuf,
                           size) != HAL_OK)
    {
        return USBD_FAIL;
    }

    return USBD_OK;
}

uint32_t USBD_LL_GetRxDataSize(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
    return HAL_PCD_EP_GetRxCount((PCD_HandleTypeDef *)pdev->pData, ep_addr);
}

void USBD_LL_Delay(uint32_t Delay)
{
    HAL_Delay(Delay);
}

static void USB_PCD_ResetCallback(PCD_HandleTypeDef *hpcd)
{
    USBD_LL_SetSpeed((USBD_HandleTypeDef *)hpcd->pData, USBD_SPEED_FULL);
    USBD_LL_Reset((USBD_HandleTypeDef *)hpcd->pData);
}

static void USB_PCD_SetupCallback(PCD_HandleTypeDef *hpcd)
{
    USBD_LL_SetupStage((USBD_HandleTypeDef *)hpcd->pData,
                       (uint8_t *)hpcd->Setup);
}

static void USB_PCD_DataOutCallback(PCD_HandleTypeDef *hpcd, uint8_t epnum)
{
    USBD_LL_DataOutStage((USBD_HandleTypeDef *)hpcd->pData,
                         epnum,
                         hpcd->OUT_ep[epnum].xfer_buff);
}

static void USB_PCD_DataInCallback(PCD_HandleTypeDef *hpcd, uint8_t epnum)
{
    USBD_LL_DataInStage((USBD_HandleTypeDef *)hpcd->pData,
                        epnum,
                        hpcd->IN_ep[epnum].xfer_buff);
}
